<?php
define('FICHERO', 'incidencias.txt');

if(!empty($_POST['fichero']) && (is_readable($_POST['fichero']))){

    $lista= [];
    
    $fichero = @fopen(FICHERO,"r") or die ("Error al abrir el fichero.");
    
    while ($linea = fgets($fichero)) {
        
        $elementos = explode(",", $linea);
        $fecha = $elementos[0];
        $hora = $elementos[1];
        $resumen = $elementos[2];
        $nombre = $elementos[3];
        $prioridad = $elementos[4];
        $ip = $elementos[5];
        
        $lista[] = 

    }
    fclose($fichero);
    


    
    
    
}
?>